const url = "https://openrouter.ai/api/v1/chat/completions";

async function getCareerGuidance() {
    const params = new URLSearchParams(window.location.search);

  const data = {
    name:params.get("name"),
    age:params.get("age"),
    skills: params.get("skills"),
    subject: params.get("subject"),
    careerInterest: params.get("careerInterest"),
    goal: params.get("goal"),
  };

  const requestBody = {
    model: "openai/gpt-4-turbo",
    max_tokens: 1000,
    messages: [
      {
        role: "system",
        content: "You are a Career Guidance Coach for Indian students.",
      },
      {
        role: "user",
        content: `Provide career guidance for:
Name: ${data.name}
Age: ${data.age}
Skills: ${data.skills}
Subject: ${data.subject}
Interest: ${data.careerInterest}
Goal: ${data.goal}

Give output as:
1. Career Recommendations
2. Courses & Certifications
3. Job Trends`, 
      },
    ],
  };

  const options = {
    method: "POST",
    headers: {
      Authorization:
        "Bearer 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", // Replace this
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestBody),
  };

  try {
    const response = await fetch(url, options);
    const result = await response.json();

    const text = result.choices[0].message.content;
    const parts = text.split(/\d+\.\s/);

    document.getElementById("recommendations").value =parts[1]?.trim();
    document.getElementById("courses").value = parts[2]?.trim();
    document.getElementById("jobTrends").value = parts[3]?.trim();
  } catch (err) {
    console.error("Error fetching guidance:", err);
  }
}

window.onload = getCareerGuidance;
